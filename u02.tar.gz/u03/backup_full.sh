#!/bin/bash

# Validar la disponibilidad del directorio origen
check_source() {
    if [ ! -d "$1" ]; then
        echo "El directorio de origen $1 no existe"
        exit 1
    fi
}

# Validar la disponibilidad del directorio destino
check_destination() {
    if [ ! -d "$1" ]; then
        echo "El directorio de destino $1 no existe"
        exit 1
    fi
}

# Realizar el backup de un directorio
perform_backup() {
    source_dir=$1
    dest_dir=$2

    # Validar la disponibilidad del origen y destino
    check_source "$source_dir"
    check_destination "$dest_dir"

    # Obtener el nombre del directorio sin la ruta
    dir_name=$(basename "$source_dir")

    # Obtener la fecha actual en formato ANSI
    fecha=$(date +"%Y%m%d")

    # Generar el nombre del archivo de backup
    backup_file="$dest_dir/${dir_name}_bkp_${fecha}.tar.gz"

    # Realizar el backup comprimiendo el directorio
    tar -czf "$backup_file" "$source_dir"

    # Verificar el resultado del comando tar
    if [ $? -eq 0 ]; then
        echo "Se ha realizado el backup de $source_dir correctamente"
    else
        echo "Ha ocurrido un error al realizar el backup de $source_dir"
        exit 1
    fi
}

# Directorios y horarios de backup
source_dirs=(
    "/etc"
    "/var/logs"
)
dest_dir="/u0"

# Obtener el día de la semana (0-6, donde 0 es domingo)
day_of_week=$(date +"%w")

# Obtener la hora actual
current_hour=$(date +"%H")

# Realizar el backup diario
if [ $current_hour -eq 0 ]; then
    for dir in "${source_dirs[@]}"; do
        perform_backup "$dir" "$dest_dir"
    done
fi

# Realizar el backup semanal (solo los domingos a las 23 hs)
if [ $day_of_week -eq 0 ] && [ $current_hour -eq 23 ]; then
    source_dirs+=(
        "/u01"
        "/u02"
    )
    for dir in "${source_dirs[@]}"; do
        perform_backup "$dir" "$dest_dir"
    done
fi


